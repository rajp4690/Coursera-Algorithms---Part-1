import java.util.LinkedList;

public class Board{
    private int[][] blocks;

    public Board(int[][] blocks){
        this.blocks = new int[blocks.length][blocks.length];
        for(int i = 0; i < blocks.length; i++){
            for(int j = 0; j < blocks.length; j++){
                this.blocks[i][j] = blocks[i][j];
            }
        }
    }

    public int dimension(){
        return blocks.length;
    }

    public int hamming(){
        int count = 0;
        for(int i = 0; i < blocks.length; i++){
            for(int j = 0; j < blocks.length; j++){
                if(blockNotInPlace(i, j))
                    count ++;
            }
        }
        return count;
    }

    private boolean blockNotInPlace(int row, int column){
        return(blocks[row][column] != 0 && blocks[row][column] != block2Dto1D(row, column));
    }

    private int block2Dto1D(int row, int column){
        return row * dimension() + column + 1;
    }

    public int manhattan(){
        int distance = 0;
        for(int i = 0; i < blocks.length; i++){
            for(int j = 0; j < blocks.length; j++){
                int block = blocks[i][j];
                if(block != 0){
                    distance += Math.abs(i - (block - 1) /dimension()) + Math.abs(j - (block - 1) % dimension());
                }
            }
        }
        return distance;
    }

    public boolean isGoal(){
        for(int i = 0; i < blocks.length; i++){
            for(int j = 0; j < blocks.length; j++){
                if(blockNotInPlace(i, j))
                    return false;
            }
        }
        return true;
    }

    public Board twin(){
        for(int i = 0; i < blocks.length; i++){
            for(int j = 0; j < blocks.length - 1; j++){
                if(blocks[i][j] != 0 && blocks[i][j + 1] != 0)
                    return new Board(swap(i, j, i, j + 1));
            }
        }
        throw new RuntimeException();
    }

    private int[][] swap(int r1, int c1, int r2, int c2){
        int[][] answer = new int[blocks.length][blocks.length];
        for(int i = 0; i < blocks.length; i++){
            for(int j = 0; j < blocks.length; j++){
                answer[i][j] = blocks[i][j];
            }
        }
        int temp = answer[r1][c1];
        answer[r1][c1] = answer[r2][c2];
        answer[r2][c2] = temp;
        return answer;
    }

    public boolean equals(Object y){
        if(y == this)
            return true;
        if(y == null || !(y instanceof Board) || ((Board)y).blocks.length != blocks.length)
            return false;
        for(int i = 0; i < blocks.length; i++){
            for(int j = 0; j < blocks.length; j++){
                if(((Board)y).blocks[i][j] != blocks[i][j])
                    return false;
            }
        } 
        return true;
    }

    public Iterable<Board> neighbors(){
        LinkedList<Board> neighbors = new LinkedList<>();
        int spaceRow = 0, spaceCol = 0;

        for(int i = 0; i < blocks.length; i++){
            for(int j = 0; j < blocks.length; j++){
                if(blocks[i][j] == 0){
                    spaceRow = i;
                    spaceCol = j;
                    break;
                }    
            }
        }

        if(spaceRow > 0)
            neighbors.add(new Board(swap(spaceRow, spaceCol, spaceRow - 1, spaceCol)));
        if(spaceRow < blocks.length - 1)
            neighbors.add(new Board(swap(spaceRow, spaceCol, spaceRow + 1, spaceCol)));
        if(spaceCol > 0)
            neighbors.add(new Board(swap(spaceRow, spaceCol, spaceRow, spaceCol - 1)));
        if(spaceCol < blocks.length - 1)
            neighbors.add(new Board(swap(spaceRow, spaceCol, spaceRow, spaceCol + 1)));

        return neighbors;
    }

    public String toString(){
        StringBuilder str = new StringBuilder();
        str.append(dimension() + "\n");
        for (int row = 0; row < blocks.length; row++) {
            for (int col = 0; col < blocks.length; col++)
                str.append(String.format("%2d ", blocks[row][col]));
            str.append("\n");
        }

        return str.toString();
    }
}
import edu.princeton.cs.algs4.MinPQ;
import java.util.Stack;
import edu.princeton.cs.algs4.StdOut;
import edu.princeton.cs.algs4.In;

public class Solver{
    private class Node implements Comparable<Node>{
        private Board board;
        private Node previous;
        private int moves = 0;

        public Node(Board board){
            this.board = board;
        }

        public Node(Board board, Node previous){
            this.board = board;
            this.previous = previous;
            this.moves = previous.moves + 1;
        }

        public int compareTo(Node node){
            return(this.board.manhattan() - node.board.manhattan()) + (this.moves - node.moves);
        }
    }

    private Node finalNode;

    public Solver(Board initial){
        if(initial == null)
            throw new IllegalArgumentException();
        MinPQ<Node> queue = new MinPQ<Node>();
        MinPQ<Node> twinQueue = new MinPQ<Node>();
        
        queue.insert(new Node(initial));
        twinQueue.insert(new Node(initial.twin()));

        while(true){
            finalNode = calculate(queue);
            if(finalNode != null || calculate(twinQueue) != null)
                return;
        }
    }

    private Node calculate(MinPQ<Node> queue){
        if(queue.isEmpty())
            return null;
        Node bestNode = queue.delMin();
        if(bestNode.board.isGoal())
            return bestNode;
        for(Board neighbor : bestNode.board.neighbors()){
            if(bestNode.previous == null || !neighbor.equals(bestNode.previous.board))
                queue.insert(new Node(neighbor, bestNode));            
        }
        return null;
    }
    
    public boolean isSolvable(){
        return (finalNode != null);
    }

    public int moves(){
        return isSolvable() ? finalNode.moves : -1;
    }

    public Iterable<Board> solution(){
        if(!isSolvable())
            return null;
        Node current = finalNode;
        Stack<Board> temp = new Stack<Board>();
        while(current != null){
            temp.push(current.board);
            current = current.previous;
        }
        Stack<Board> answer = new Stack<Board>();
        while(!temp.isEmpty()){
            answer.push(temp.pop());
        }
        return answer;
    }

    public static void main(String[] args) {

    // create initial board from file
    In in = new In(args[0]);
    int n = in.readInt();
    int[][] blocks = new int[n][n];
    for (int i = 0; i < n; i++)
        for (int j = 0; j < n; j++)
            blocks[i][j] = in.readInt();
    Board initial = new Board(blocks);

    // solve the puzzle
    Solver solver = new Solver(initial);

    // print solution to standard output
    if (!solver.isSolvable())
        StdOut.println("No solution possible");
    else {
        StdOut.println("Minimum number of moves = " + solver.moves());
        for (Board board : solver.solution())
            StdOut.println(board);
    }
}

}
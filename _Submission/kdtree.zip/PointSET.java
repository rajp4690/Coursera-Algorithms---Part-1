import edu.princeton.cs.algs4.Point2D;
import edu.princeton.cs.algs4.RectHV;
import java.util.LinkedList;
import java.util.List;
import java.util.TreeSet;
import edu.princeton.cs.algs4.StdOut;
import edu.princeton.cs.algs4.StdDraw;
import edu.princeton.cs.algs4.In;

public class PointSET {
    private TreeSet<Point2D> pointSet;

    public PointSET() {
        pointSet = new TreeSet<Point2D>();
    }

    public boolean isEmpty() {
        return size() == 0;
    }

    public int size() {
        return pointSet.size();
    }

    public void insert(Point2D p) {
        if(p == null) {
            throw new IllegalArgumentException();
        }
        pointSet.add(p);
    }

    public boolean contains(Point2D p) {
        if(p == null) {
            throw new IllegalArgumentException();
        }
        return pointSet.contains(p);
    }

    public void draw() {
        for(Point2D point : pointSet){
            point.draw();
        }
    }

    public Iterable<Point2D> range(RectHV rect) {
        if(rect == null) {
            throw new IllegalArgumentException();
        }
        List<Point2D> pointsInRec = new LinkedList<>();

        for(Point2D point : pointSet) {
            if(rect.contains(point)) {
                pointsInRec.add(point);
            }
        }

        return pointsInRec;
    }

    public Point2D nearest(Point2D p) {
        if(p == null) {
            throw new IllegalArgumentException();
        }
        if(size() == 0) {
            return null;
        }
        Point2D nearestPoint = null;
        for(Point2D point : pointSet) {
            if(nearestPoint == null) {
                nearestPoint = point;
            }
            else if(p.distanceSquaredTo(point) < p.distanceSquaredTo(nearestPoint)) {
                nearestPoint = point;
            }
        }
        return nearestPoint;
    }

    public static void main(String[] args) {
        StdOut.println("hello world");
        KdTree kdtree = new KdTree();
        assert kdtree.size() == 0;
        kdtree.insert(new Point2D(.7, .2));
        assert kdtree.size() == 1;
        kdtree.insert(new Point2D(.5, .4));
        kdtree.insert(new Point2D(.2, .3));
        kdtree.insert(new Point2D(.4, .7));
        kdtree.insert(new Point2D(.9, .6));
        assert kdtree.size() == 5;

        StdOut.println("size: " + kdtree.size());
        //StdOut.println(kdtree);

        kdtree = new KdTree();
        kdtree.insert(new Point2D(0.206107, 0.095492));
        kdtree.insert(new Point2D(0.975528, 0.654508));
        kdtree.insert(new Point2D(0.024472, 0.345492));
        kdtree.insert(new Point2D(0.793893, 0.095492));
        kdtree.insert(new Point2D(0.793893, 0.904508));
        kdtree.insert(new Point2D(0.975528, 0.345492));
        assert kdtree.size() == 6;

        StdOut.println("size: " + kdtree.size());
        kdtree.insert(new Point2D(0.306107, 0.904508));
        StdOut.println(kdtree);
        assert kdtree.size() == 7;

        StdOut.println("size: " + kdtree.size());

        /*
        StdDraw.show(0);
        StdDraw.setPenRadius(.02);
        kdtree.draw();
        StdDraw.show(0);
         */


        /*
        String filename;
        In in;
        // Test 1a: Insert N distinct points and check size() after each insertion
        // 100000 random distinct points in 100000-by-100000 grid
        filename = "kdtree/input100K.txt";
        in = new In(filename);
        kdtree = new KdTree();
        for (int i = 0; i < 100000; i++) {
            double x = in.readDouble();
            double y = in.readDouble();
        }
         */

    }
}
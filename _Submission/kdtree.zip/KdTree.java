import edu.princeton.cs.algs4.Point2D;
import edu.princeton.cs.algs4.RectHV;
import java.util.LinkedList;
import java.util.List;
import java.util.TreeSet;
import edu.princeton.cs.algs4.StdOut;
import edu.princeton.cs.algs4.StdDraw;
import edu.princeton.cs.algs4.In;

public class KdTree {
    private class Node {
        Point2D point;
        Node left;
        Node right;
        boolean isVertical;

        Node(Point2D point, Node left, Node right, boolean isVertical) {
            this.point = point;
            this.left = left;
            this.right = right;
            this.isVertical = isVertical;
        }
    }

    private Node root;
    private int size;
    private Point2D nearest;
    private List<Point2D> pointsInRec;

    private static final RectHV MAIN_REC = new RectHV(0, 0, 1, 1);

    public KdTree() {
        root = null;
        size = 0;
        nearest = null;
    }

    public boolean isEmpty() {
        return size == 0;
    }

    public int size() {
        return size;
    }
    public void insert(Point2D p) {
        if(p == null) {
            throw new IllegalArgumentException();
        }
        root = insertHelper(p, root, true);
    }

    private Node insertHelper(Point2D p, Node temp, boolean isVertical) {
        if(temp == null) {
            size++; 
            return new Node(p, null, null, isVertical);
        }
        else if(p.equals(temp.point)) {
            return temp;
        }
        else if(compare(p, temp) < 0) {
            temp.left = insertHelper(p, temp.left, !temp.isVertical);
        }
        else {
            temp.right = insertHelper(p, temp.right, !temp.isVertical);
        }
        return temp;
    }

    private int compare(Point2D p, Node node) {
        if(node.isVertical) {
            if(p.x() < node.point.x())
                return -1;
            else if (p.x() > node.point.x())
                return 1;
            else 
                return 0;
        }
        else {
            if(p.y() < node.point.y())
                return -1;
            else if (p.y() > node.point.y())
                return 1;
            else 
                return 0;
        }
    }

    public boolean contains(Point2D p) {
        if(p == null) {
            throw new IllegalArgumentException();
        }
        else {
            return containsHelper(p, root);
        }
    }

    private boolean containsHelper(Point2D p, Node temp) {
        if(temp != null) {
            if(temp.point.equals(p))
                return true;
            if(compare(p, temp) < 0)
                return containsHelper(p, temp.left);
            else
                return containsHelper(p, temp.right);
        }
        return false;
    }

    public void draw() {
        drawHelper(root);
    }

    private void drawHelper(Node temp) {
        if(temp != null) {
            temp.point.draw();
            drawHelper(temp.left);
            drawHelper(temp.right);
        }
    }

    public Iterable<Point2D> range(RectHV rec) {
        if(rec == null){
            throw new IllegalArgumentException();
        }
        pointsInRec = new LinkedList<>();
        rangeHelper(rec, MAIN_REC, root);
        return pointsInRec;
    }

    private void rangeHelper(RectHV rec, RectHV nodeRec, Node temp) {
        if(temp != null){
            if(rec.intersects(nodeRec)) {
                if(rec.contains(temp.point)) {
                    pointsInRec.add(temp.point);
                }
                rangeHelper(rec, getRec(temp, nodeRec, true), temp.left);
                rangeHelper(rec, getRec(temp, nodeRec, false), temp.right);
            }
        }
    }

    public Point2D nearest(Point2D p) {
        if(p == null) {
            throw new IllegalArgumentException();
        }
        if(root != null){
            nearest = null;
            nearestHelper(p, root, MAIN_REC);
        }
        return nearest;
    }   

    private void nearestHelper(Point2D p, Node temp, RectHV rec) {
        if(temp != null) {
            RectHV leftRec = null;
            RectHV rightRec = null;
            if(nearest == null || rec.distanceSquaredTo(p) < p.distanceSquaredTo(nearest)) {
                if(nearest == null) {    
                    nearest = temp.point;
                }
                else if(p.distanceSquaredTo(temp.point) < p.distanceSquaredTo(nearest)) {
                    nearest = temp.point;
                }    
                    leftRec = getRec(temp, rec, true); // true value means left/bottom rectangle
                    rightRec = getRec(temp, rec, false); // false value means right/top rectangle
                    if(compare(p, temp) < 0) {
                        nearestHelper(p, temp.left, leftRec);
                        nearestHelper(p, temp.right, rightRec);
                    }
                    else {
                        nearestHelper(p, temp.right, rightRec);
                        nearestHelper(p, temp.left, leftRec);
                    }
            }         
        }
    }

    private RectHV getRec(Node node, RectHV rect, boolean isLeft) {
        if(node.isVertical) {
            if(isLeft)
                return new RectHV(rect.xmin(), rect.ymin(), node.point.x(), rect.ymax());
            else
                return new RectHV(node.point.x(), rect.ymin(), rect.xmax(), rect.ymax());
        }
        else {
            if(isLeft)
                return new RectHV(rect.xmin(), rect.ymin(), rect.xmax(), node.point.y());
            else
                return new RectHV(rect.xmin(), node.point.y(), rect.xmax(), rect.ymax());
        }
    }

    public static void main(String[] args) {
        KdTree kdtree = new KdTree();

        if (args.length != 0) {
            In in = new In(args[0]);
            double x, y;
            while (!in.isEmpty()) {
                x = in.readDouble();
                if (!in.isEmpty()) {
                    y = in.readDouble();
                    kdtree.insert(new Point2D(x, y));
                }
            }

            Point2D temp = kdtree.nearest(new Point2D(0.81, 0.30));
            kdtree.draw();
         }
         


        /*kdtree.insert(new Point2D(0.206107 ,0.095492));
        kdtree.insert(new Point2D(0.975528 ,0.654508));
        kdtree.insert(new Point2D(0.024472 ,0.345492));
        kdtree.insert(new Point2D(0.793893, 0.095492));
        kdtree.insert(new Point2D(0.793893, 0.904508));
        kdtree.insert(new Point2D(0.975528, 0.345492));
        kdtree.insert(new Point2D(0.206107 ,0.904508));
        kdtree.insert(new Point2D(0.500000 ,0.000000));
        kdtree.insert(new Point2D(0.024472 ,0.654508));
        kdtree.insert(new Point2D(0.500000 ,1.000000));

        Point2D temp = kdtree.nearest(new Point2D(0.81, 0.30));

        kdtree.draw();*/

    }
}
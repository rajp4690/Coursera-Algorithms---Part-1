import java.util.Iterator;
import java.util.NoSuchElementException;  

public class Deque<Item> implements Iterable<Item> {
  private Item[] deque;
  private int head, tail;
  private int manyItems;

  public Deque(){
    deque = (Item[]) new Object[1];
    head = 0;
    tail = 0;
    manyItems = 0;
  }                       

  public boolean isEmpty(){
    return (manyItems == 0);
  }                 

  public int size(){
    return manyItems;
  }                  

  public void addFirst(Item item){
    if(item == null)
      throw new IllegalArgumentException();
    if(manyItems == deque.length)
      ensureCapacity(deque);
    if(head == 0)
      head = deque.length - 1;
    else
      head--;
    deque[head] = item;
    manyItems++;
  }

  public void addLast(Item item){
    if(item == null)
      throw new IllegalArgumentException();
    ensureCapacity(deque);
    if(tail == deque.length - 1)
      tail = 0;
    else 
      tail++;
    deque[tail] = item;
    manyItems++;
  }        

  public Item removeFirst(){
    if(isEmpty())
      throw new NoSuchElementException();
    Item answer = deque[head];
    deque[head] = null;
    if(head == deque.length - 1)
      head = 0;
    else
      head++;
    manyItems--;
    ensureCapacity(deque);
    return answer;
  }

  public Item removeLast(){
    if(isEmpty())
      throw new NoSuchElementException();
    Item answer = deque[tail];
    deque[tail] = null;
    if(tail == 0)
      tail = deque.length - 1;
    else
      tail--;
    manyItems--;
    ensureCapacity(deque);  
    return answer;
  }

  public Iterator<Item> iterator(){
    return new  ArrayIterator();
  }

  private class ArrayIterator implements Iterator<Item>{
    private int i = head;
    private int count = manyItems;

    public boolean hasNext(){
      return count > 0;
    }

    public Item next(){
      if(!hasNext())
        throw new NoSuchElementException();
      if(i == deque.length)
        i = 0;
      count--;
      return deque[i++];
    }

    public void remove(){
      throw new UnsupportedOperationException();
    }
  }

  private void ensureCapacity(Item[] item){
    Item[] newItem;
    if(manyItems == item.length){
      newItem = (Item[]) new Object[item.length * 2];
    }
    else if(manyItems > 0 && manyItems <= item.length / 4){
      newItem = (Item[]) new Object[item.length / 2];
    }
    else  
      return;
    int j = 0;
    int end;
    if(head <= tail){
      for(int i = head; i <= tail; i++){
        newItem[j] = item[i];
        j++;
      }
    }
    else{
      for(int i = head; i < item.length; i++){
        newItem[j] = item[i];
        j++;
      }
      for(int i = 0; i <= tail; i++){
        newItem[j] = item[i];
        j++;
      }
    }  
    deque = newItem;
    head = 0;
    tail = manyItems - 1;
  } 

  public static void main(String[] args) {

        Deque<Integer> deq2 = new Deque<Integer>();

        System.out.println("deq2: " + deq2.toString());
        System.out.println("size: " + deq2.size());

        deq2.addFirst(1);
        deq2.addFirst(2);
        deq2.addFirst(3);
        deq2.addFirst(4);
        deq2.addFirst(5);


        System.out.println("deq2: " + deq2.toString());

        deq2.removeLast();
        System.out.println("deq2: " + deq2.toString());

        deq2.removeFirst();
        deq2.removeFirst();
        System.out.println("deq2: " + deq2.toString());
        System.out.println("size: " + deq2.size());

        deq2.removeLast();
        deq2.removeLast();
        System.out.println("deq2: " + deq2.toString());

        deq2.addFirst(1);
        deq2.addLast(2);
        System.out.println("deq2: " + deq2.toString());

        deq2.addFirst(3);
        deq2.addLast(4);
        System.out.println("deq2: " + deq2.toString());

        System.out.println("size: " + deq2.size());



        Iterator itr = deq2.iterator();

        //System.out.println(itr.);
        System.out.println(itr.next());
        System.out.println(itr.next());
        System.out.println(itr.next());
        System.out.println(itr.next());
        //System.out.println(itr.next());

    }

}
import java.util.Iterator;
import java.util.NoSuchElementException;  
import edu.princeton.cs.algs4.StdRandom;

public class RandomizedQueue<Item> implements Iterable<Item> {
  private Item[] randomizedQueue;
  private int manyItems;

  public RandomizedQueue(){
  randomizedQueue = (Item[]) new Object[1];
  manyItems = 0;
  }                 
  
  public boolean isEmpty(){
    return manyItems == 0;
  }            

  public int size(){
    return manyItems;
  }                        
  public void enqueue(Item item){
    if(item == null)
      throw new IllegalArgumentException();
    ensureCapacity(randomizedQueue);
    randomizedQueue[manyItems] = item;
    manyItems++;
  }

  public Item dequeue(){
    if(isEmpty())
      throw new NoSuchElementException();
    int random = StdRandom.uniform(manyItems); 
    Item answer = randomizedQueue[random];
    randomizedQueue[random] = randomizedQueue[manyItems - 1];
    randomizedQueue[manyItems - 1] = null;
    manyItems--;
    ensureCapacity(randomizedQueue);
    return answer;
  }           

  public Item sample(){
    if(isEmpty())
      throw new NoSuchElementException();
    int random = StdRandom.uniform(manyItems);
    return randomizedQueue[random];
  }                     
  public Iterator<Item> iterator(){
    return new RandomizedIterator();
  }        

  private class RandomizedIterator implements Iterator<Item>{
    Item[] temp = (Item[]) new Object[manyItems];
    int count = manyItems;

    RandomizedIterator(){
      for(int i = 0; i < manyItems; i++){
        temp[i] = randomizedQueue[i];
      }
    }

    public boolean hasNext(){
      return count > 0;
    }

    public Item next(){
      if(!hasNext())
        throw new NoSuchElementException();
      int random = StdRandom.uniform(count);
      Item answer = temp[random];
      temp[random] = temp[--count];
      temp[count] = answer;
      return answer;
    }

    public void remove(){
      throw new UnsupportedOperationException();
    }
  }

   private void ensureCapacity(Item[] item){
    Item[] newItem;
    if(manyItems == item.length){
      newItem = (Item[]) new Object[item.length * 2];
    }
    else if(manyItems > 0 && manyItems <= item.length / 4){
      newItem = (Item[]) new Object[item.length / 2];
    }
    else  
      return;
    for(int i = 0; i < manyItems; i++){
      newItem[i] = item[i];
    }
    randomizedQueue = newItem;
  } 

  public static void main(String[] args){
    RandomizedQueue<Integer> rqueue = new RandomizedQueue<Integer>();
    rqueue.enqueue(1);
    rqueue.enqueue(2);
    rqueue.enqueue(3);
    rqueue.enqueue(4);
    rqueue.enqueue(5);
    rqueue.enqueue(6);
    rqueue.enqueue(7);
    rqueue.enqueue(8);
    Iterator<Integer> it = rqueue.iterator();
    while (it.hasNext()) {
       int elt = it.next();
       System.out.println(elt + " ");
    }
  } 
}
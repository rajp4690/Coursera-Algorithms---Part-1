import edu.princeton.cs.algs4.WeightedQuickUnionUF;
import java.util.*;

public class Percolation{
  private int gridSize, openCells;
  private int top, bottom;
  private WeightedQuickUnionUF grid;
  private WeightedQuickUnionUF gridPerc;
  private int[] cell;

  public Percolation(int n){
    gridSize = n;
    gridPerc = new WeightedQuickUnionUF(gridSize * gridSize + 2);
    cell = new int[gridSize * gridSize];
    top = 0;
    bottom = gridSize * gridSize + 1;
  }

  public void open(int i, int j){
    isInRange(i, j);
    if(isOpen(i, j))
      return;
    int currentCell = convt2dto1d(i, j);
    cell[currentCell] = 1;
    openCells++;

    if(i == 1 && !gridPerc.connected(currentCell, top)){
      gridPerc.union(currentCell, top);
    }

    if(i == gridSize){  
      gridPerc.union(currentCell, bottom);
    }

    if(i > 1){
      if(isOpen(i - 1, j)){
        gridPerc.union(currentCell, convt2dto1d(i - 1, j));
      }
    }

    if(i < gridSize){
      if(isOpen(i + 1, j)){
        gridPerc.union(currentCell, convt2dto1d(i + 1, j));
      }
    }

    if(j > 1){
      if(isOpen(i, j - 1)){
        gridPerc.union(currentCell, convt2dto1d(i, j - 1));
      }
    }

    if(j < gridSize){
      if(isOpen(i, j + 1)){
        gridPerc.union(currentCell, convt2dto1d(i, j + 1));
      }
    }
  }

  public int numberOfOpenSites(){
    return openCells;
  }

  private int convt2dto1d(int i, int j){
    return (gridSize * (i - 1) + j - 1);
  }

  private boolean isInRange(int i, int j){
    if(i < 1 || i > gridSize || j < 1 || j > gridSize)
      throw new IndexOutOfBoundsException();
    return true;
  }

  public boolean isOpen(int i, int j){
    isInRange(i, j);
    if(cell[convt2dto1d(i, j)] == 1)
      return true;
    return false;
  }

  public boolean isFull(int i, int j){
    isInRange(i, j);
    if(!isOpen(i, j))
      return false;
    if(gridPerc.connected(convt2dto1d(i, j), top))
      return true;
    return false;
  }

  public boolean percolates(){
    if(gridPerc.connected(top, bottom))
      return true;
    return false;
  }

}
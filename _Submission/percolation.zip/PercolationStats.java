import edu.princeton.cs.algs4.*;
import java.util.*;

public class PercolationStats{

  private int gridSize;
  private double[] thresholds;
  private int trials;

  public PercolationStats(int n, int trials){
    if(n <= 0 || trials <= 0)
      throw new IllegalArgumentException();
    gridSize = n;
    this.trials = trials;
    thresholds = new double[trials];

    for(int i = 0; i < trials; i++)
      thresholds[i] = percolationThreshold();
  }

  public double mean(){
    return StdStats.mean(thresholds);
  }

  public double stddev(){
    if(trials == 1) return Double.NaN;
    return StdStats.stddev(thresholds);
  }

  public double confidenceLo(){
    return mean() - (1.96 * stddev() / Math.sqrt(trials));
  }

  public double confidenceHi(){
    return mean() + (1.96 * stddev() / Math.sqrt(trials));
  }

  private double percolationThreshold(){
    Percolation perc = new Percolation(gridSize);
    int x,y;
    int openSites = 0;
    while(!perc.percolates()){
      x = StdRandom.uniform(gridSize) + 1;
      y = StdRandom.uniform(gridSize) + 1;
      while(!perc.isOpen(x, y)){
        perc.open(x, y);
        openSites++;
      }
    }
    return openSites / Math.pow(gridSize, 2);
  }

  public static void main(String[] args){
    int size = Integer.parseInt(args[0]);
    int experiments = Integer.parseInt(args[1]);
    PercolationStats percStats = new PercolationStats(size, experiments);
    StdOut.printf("mean \t\t\t= %f\n", percStats.mean());
    StdOut.printf("stddev \t\t\t= %f\n", percStats.stddev());
    StdOut.printf("95%% confidence interval = [%f, %f]", percStats.confidenceLo(), percStats.confidenceHi());
  }
}